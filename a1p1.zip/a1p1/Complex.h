/*CH08-320143
a1p1.cpp
SHOROUK GABR AWWAD
s.awwad@jacobs-university.de*/

#ifndef COMPLEX_H
#define COMPLEX_H
#include <iostream>


class Complex
{
    public:

        Complex();
        Complex(float r, float i);
        Complex (Complex &obj);
         void setReal (float r1);
         void setImag (float i);
         float getReal ();
         float getImage();

        virtual ~Complex();

        Complex operator + (const Complex& a);

        Complex operator - (const Complex& a);

        Complex operator * (const Complex& a);

        Complex operator = (const Complex& a);

       friend std::ostream& operator<<(std::ostream& o, const Complex& aw);
       friend std:: istream& operator>>(std::istream& i, Complex& aw);


    protected:

    private:
        float imag;
        float real;

};


#endif // COMPLEX_H
