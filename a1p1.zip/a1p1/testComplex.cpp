/*CH08-320143
a1p1.cpp
SHOROUK GABR AWWAD
s.awwad@jacobs-university.de*/

#include <iostream>
#include "Complex.h"
#include <fstream>

using namespace std;
int main(){

 ifstream in1;
if (!in1.is_open())			// check is_open
    in1.open("in1.txt",ios::in);
if (!in1.good()) {
    cout << "Error" << endl;
    exit(1);
}

ifstream in2;
if (!in2.is_open())			// check is_open
in2.open("in2.txt",ios::in);

if (!in2.good()) {
    cout << "Error" << endl;
    exit(1);
}
ofstream out;
if (!out.is_open())
out.open("output.txt", ios::out);
if (!out.good()) {
    cout << "Error" << endl;
    exit(1);
}

Complex a,b,sum, diff, prod;
in1>>a;
    in2>>b;
    sum = a+b;
    diff= a-b;
    prod = a*b;

    cout <<"THe two complex numbers: \n";
    cout <<a<<b;
    out <<"THe two complex numbers: \n";
    out <<a<<b;

    cout << "The sum:\n";
    cout << sum;
    out << "The sum:\n";
    out << sum;

    cout << "THe difference: \n";
    cout <<diff;

    out << "THe difference: \n";
    out <<diff;

    cout << "The product:\n";
    cout << prod;
    out << "The product:\n";
    out << prod;

    in1.close();
    in2.close();
    out.close();
}
