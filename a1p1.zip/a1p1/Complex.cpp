/*CH08-320143
a1p1.cpp
SHOROUK GABR AWWAD
s.awwad@jacobs-university.de*/
#include <iostream>
#include <string>
#include "Complex.h"

using namespace std;
Complex::Complex()
{
    real = imag =0;  //ctor
}
//constructor
Complex :: Complex(float r, float i)
{
    real =r;
    imag =i;

}
//copy constructor

Complex :: Complex (Complex &obj)
{
    real =obj.real;
    imag=obj.imag;

}

Complex Complex::operator + (const Complex& a)
{
//operator +
    Complex C;
    C.real= real + a.real;
    C.imag= imag + a.imag;
    return C;

}
Complex Complex::operator - (const Complex& a)
{//operator -

    Complex C;
    C.real= real - a.real;
    C.imag= imag - a.imag;
    return C;

}
Complex Complex::operator * (const Complex& a)
{//operator *
    Complex C;
    C.real = (real*a.real)-(imag*a.imag);
    C.imag = real*a.imag +a.real *imag;

    return C;

}

Complex Complex::operator = (const Complex& a)
{
// operator =
    real = a.real;
    imag = a.imag;
    return *this;

}


std::istream& operator>>(std::istream& i, Complex& aw)
{
    // gets both data members from the stream
    i>>aw.real >> aw.imag;
// removed trailing \n
    return i;
}

std ::ostream& operator<<(std::ostream& o, const Complex& aw)
{
    // writes both data members to the stream
    o << noshowpos << aw.real << showpos << aw.imag<<"i"<< endl;
    return o;
}


Complex::~Complex()
{
    //dtor
}
