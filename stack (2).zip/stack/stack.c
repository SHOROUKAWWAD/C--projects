/* JTK-03//010110
a5.p1
s.awwad@jacobs-university.de
30002030
*/


#include <stdio.h>
#include "stack.h"
// push the first element on the stack
void push(struct stack *b,const char* elem)
{



    //printf("Pushing %d\n" , elem);
  strcpy (b->array[b->count], elem);
    b->count++;

}

// pop element
char* pop(struct stack *b)
{
    if (b->count==0){
        printf("the stack is empty");

    }
    b->count--;
    return b->array[b->count];
}

int full (struct stack *b){
if (b->count ==11){
    return 1;

}else {
return 0;
}

}

void empty(struct stack *b)
{
    printf("Emptying Stack ");
    while (1)
    {
        if (b->count == 0)
        {
            break;
        }
        printf("%s " , pop(b));
    }
    printf("\n");
}

int isEmpty(struct stack *b)
{
    if(b->count == 0)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}
