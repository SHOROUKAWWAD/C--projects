#ifndef STACK_H
#define STACK_H
#include <iostream>
#include <string>
using namespace std;
template <class T>
class stack
{
public:
    stack()
    {

        back = front = 0;
        size =10;

    }
    stack (int& s)
    {
        size = s;
    }
    stack (const stack& a)
    {

        a.back =back;
        a.front= front;
        a.size = size;
        a.array = array;

    }
    bool push (T& elem)
    {
        if (back==front)
        {
            array[0]= elem;
            back++;
            return true;
        }
        else if (back!= front&& back != size)
        {
            array[back]=elem;
            back++;
            return true;
        }
        else
        {
            cout <<"Couldn't push an element on the stack\n";
            return false;
        }
    }

    bool pop(T& out)
    {


        if (back==0)
        {
            cout<<"the stack is empty\n";
            return false;
        }
        out =  array[front];
        for (int i=0; i<back; i++)
        {
            array[i]=array[i+1];

        }
        back--;
        return true;
    }


    T backk (void)
    {

        return array[front];
    }

    int getNumentries()
    {

        return back-front;
    }


    virtual ~stack()
    {
        delete []array;
    }

protected:

private:

    int back;
    int  front;
    int size;
    T* array= new T[size];

};

#endif // STACK_H
