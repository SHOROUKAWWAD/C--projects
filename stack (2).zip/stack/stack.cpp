#include "stack.h"



int main(){

stack <int> hell ;

int play;
cin >> play;

hell.push(play);

}
