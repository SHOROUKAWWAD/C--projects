/* JTSK-03//010110
a5.p1
s.awwad@jacobs-university.de
30002030
*/

#include <stdio.h>
#include <stdlib.h>
#include "stack.h"

int main()
{
    struct stack* b = (struct stack*)malloc (sizeof (struct stack));
   b->count =0;
    char* s = malloc(sizeof(char)*360);
    char*copy = malloc(sizeof(char)*360);
    char* word;
    const char* dilems = " ";

    fgets(s,360,stdin);
    s[strlen(s)-1]='\0';
    strcpy(copy,s);
    while (strcmp(s,"exit")!=0)
    {
    char* rev;

     word =strtok(s,dilems);

        int i=0;
        while (word!=NULL)
        {
            if (i<12){
            push(b,word);
           word = strtok(NULL,dilems);
           i++;
            }else {
            printf("cannot push more elements in the stack!\n");
            }
        }


        rev= pop(b);
        while (b->count!= 0)
        {
            strcat(rev, " ");
            strcat (rev,pop(b));

        }
         rev[strlen(rev)]='\0';

         printf("C %s\n",copy);
         printf(" R %s\n",rev);
         printf (" S %s\n",s);

        if (strcmp(rev,copy)==0)
        {

            printf("The sentence is palindromic by words!\n");
        }
        else
        {
            printf("The sentence is not palindromic by words!\n");
        }



  fgets(s,360,stdin);
  s[strlen(s)-1]='\0';
  strcpy(copy,s);
    }
    free (b);
    free (s);
    free (copy);
    return 0;
}
