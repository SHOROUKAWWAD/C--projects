#ifndef VECTOR_H
#define VECTOR_H
#include <iostream>
#include <string>
#include "matrix.h"
class matrix ;
class vector
{
    public:
        vector();
        vector(float*a,int n);
        vector (int h){
        n=h;
        }
        vector (vector& a){
        a.n=n;
        a.realv=realv;

        }
        virtual ~vector();
        friend  vector operator * (vector& a, matrix& b);
        friend  vector operator * (matrix& b, vector& a);
         friend std::istream& operator >> ( std::istream& in,vector& a);
         friend std::ostream& operator << ( std::ostream& out,vector& a);


        void setN(int& a){
        n=a;
        }
        int getN(){
        return n;
        }

    protected:

    private:
        int n;
    float* realv= new float [n];

};

#endif // VECTOR_H
