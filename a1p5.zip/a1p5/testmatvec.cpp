#include <iostream>
#include <string>
#include "vector.h"
#include "matrix.h"
using namespace std;
vector operator*( matrix &b,  vector &a)
{
    vector vec = a;
    matrix mat = b;
    if(mat.n == vec.n)
    {
        vector v(mat.n);
        int i, j;

        for(i = 0; i < mat.n; i++)
        {
            v.realv[i] = 0;
            for(j = 0; j < v.n; j++)
            {
                v.realv[i] += (mat.real[i]*vec.realv[j]);
            }
        }
        return v;
    }
    else
    {
        cout << "Invalid matrix and vector dimensions!" << endl;
        exit(-1);
    }
}

vector operator*( vector &a,  matrix &b)
{
    vector vec = a;
    matrix mat = b;
    if(vec.n== mat.n)
    {
        vector v(mat.n);
        int i, j;

        for(i = 0; i < mat.n; i++)
        {
            v.realv[i] = 0;
            for(j = 0; j < vec.n; j++)
            {
                v.realv[i] += (mat.real[i]*vec.realv[j]);
            }
        }
        return v;
    }
    else
    {
        cout << "Invalid matrix and vector dimensions!" << endl;
        exit(-1);
    }
}


int main ()
{
    vector a;
    matrix c;
    int ni;
     cout << "some thing 1\n";
    cin>> ni;
    cout << "some thing 1\n";
    a.setN(ni);
    c.setNm(ni);
    cin>>a;
    cin>>c;
    cout <<a;
    cout <<c;
    vector b;

    cout << " the product of vector a multiplied by matrix c\n";
    b= c*a;
    cout <<b;

}
