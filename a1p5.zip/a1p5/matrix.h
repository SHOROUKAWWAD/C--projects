#ifndef MATRIX_H
#define MATRIX_H
#include <iostream>
#include "vector.h"
class vector ;
class matrix
{
public:
    matrix();
    matrix(float*a,int n);

    matrix (matrix& a){
    a.n=n;
    a.real= real;

    }


    friend  vector operator * (vector& a, matrix& b);
    friend  vector operator * (matrix& b, vector& a);
    friend std::istream& operator >> ( std::istream& in, matrix& a);
    friend std::ostream& operator <<( std::ostream& out, matrix& a);
    void setNm(int&a)
    {
        n=a;
    }

    virtual ~matrix();

protected:

private:
    int n;
    float* real= new float [n];

};

#endif // MATRIX_H
