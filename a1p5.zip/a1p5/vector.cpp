#include "vector.h"

vector::vector()
{
    //ctor
}
vector::vector(float*a,int n){
        this->n =n;
        a=realv;
        }


       std::istream& operator >> ( std::istream& in,vector& a){

        for (int i=0; i<a.n; i++){

            in>>a.realv[i];

        }
        return in;
        }

        std::ostream& operator <<( std::ostream& out, vector& a){

        for (int i=0; i<a.n; i++){

            out << a.realv[i];

        }
        return out;
        }

vector::~vector()
{
    delete []realv;
    //dtor
}
