#include "matrix.h"
#include <iostream>
#include <string>

using namespace std;
matrix::matrix()
{
    //ctor
}
matrix::matrix(float*a,int n){
        this->n =n;
        a=real;
        }
std::istream& operator >> ( std::istream& in, matrix& a){

        for (int i=0; i<a.n; i++){
cout << i<<" ";
            in>>a.real[i];
        }
        return in;
}

    std::ostream& operator <<( std::ostream& out, matrix& a){

        for (int i=0; i<a.n; i++){

            out << a.real[i];

        }
        return out;
        }


matrix::~matrix()
{
  delete []real;  //dtor
}
